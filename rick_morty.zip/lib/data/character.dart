class Character {
  final String name;
  final String race;
  final String sex;
  final String status;
  final String imageRoute;

  Character({this.name, this.race, this.sex, this.status, this.imageRoute});
}
