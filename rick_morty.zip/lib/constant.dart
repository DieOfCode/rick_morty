import 'package:flutter/material.dart';

Color mainDartColor = Color.fromRGBO(11, 30, 45, 10);
Color elementColor = Color.fromRGBO(87, 101, 113, 10);
Color lightColor = Color.fromRGBO(43, 67, 84, 10);
Color isAliveColor = Colors.green;
Color isDeadColor = Colors.red;
